# Microsoft.Bot.Component.Samples.MultiplyDialog

This sample demonstrates a custom action for [Bot Framework Composer](https://docs.microsoft.com/composer) that multiplies two numbers and returns a result.

## Getting started

* Published it to a NuGet feed.  For testing purposes, this is easiest when done to a [local feed](https://docs.microsoft.com/nuget/hosting-packages/local-feeds). After setting up the local feed, add it to the Package Manager in Composer so that your local packages can be installed in a bot.

* Once you've installed the package in Composer, you can use it in your bot.

## Feedback and issues

If you encounter any issues with this package, or would like to share any feedback please open an Issue in our [GitHub repository](https://github.com/microsoft/botbuilder-samples/issues/new/choose).
