﻿namespace V4StateBot.Models
{
    public class GreetingState
    {
        public string Name { get; set; }
        public string City { get; set; }
    }
}
