﻿using System;

namespace V4StateBot.Models
{
    public class TestDataClass
    {
        public string TestStringField { get; set; }
        public int TestIntField { get; set; }
        public Tuple<string, string> TestTuple { get; set; }
    }
}
